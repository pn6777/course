CREATE TABLE `course_content` (
    `course_number` int NOT NULL AUTO_INCREMENT,
    `name` varchar(45) NOT NULL,
    `lecture_language` varchar(20) NOT NULL,
    `frame` varchar(20) NOT NULL,
    `type` varchar(10) NOT NULL,
    `content` varchar(200) DEFAULT NULL,
    PRIMARY KEY (`course_number`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
