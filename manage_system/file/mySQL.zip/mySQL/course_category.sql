CREATE TABLE `course_category` (
    `id` int NOT NULL AUTO_INCREMENT,
    `language` varchar(20) DEFAULT NULL,
    `frame` varchar(20) DEFAULT NULL,
    `type` varchar(10) DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
