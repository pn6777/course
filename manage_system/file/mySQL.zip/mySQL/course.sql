CREATE TABLE `course` (
    `course_id` int NOT NULL AUTO_INCREMENT,
    `course_name` varchar(45) NOT NULL,
    `registr` int DEFAULT '0',
    `start_date` date NOT NULL,
    `end_date` date NOT NULL,
    `site` varchar(45) NOT NULL,
    PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
