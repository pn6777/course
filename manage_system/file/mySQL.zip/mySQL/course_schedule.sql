CREATE TABLE `course_schedule` (
    `date` date NOT NULL,
    `number` int NOT NULL,
    `course_id` int NOT NULL DEFAULT '0',
    `teaching_hours` double DEFAULT '0',
    `lecture_language` varchar(20) NOT NULL,
    `level` varchar(20) NOT NULL,
    `title` varchar(45) NOT NULL,
    PRIMARY KEY (`date`,`number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
