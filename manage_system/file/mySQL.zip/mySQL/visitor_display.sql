CREATE TABLE `visitor_display` (
    `number` int NOT NULL AUTO_INCREMENT,
    `date` date NOT NULL,
    `start_time` time DEFAULT NULL,
    `end_time` time DEFAULT NULL,
    `study_hours` double DEFAULT '0',
    PRIMARY KEY (`number`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
